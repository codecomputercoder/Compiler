volatile int variable_test;
extern int funct_1();
double funct_2(double y, double z) {
    return y + z;
}

static char func_3(char a, char b) {
    return a + b - 2 + 4;
}



void funct5() {
    int i;
    for (i = 0; i < 10; i++) {
        variable_test = i;
    }
}

/*
 multiline comment
 */


void main() {
    // single line comment
    
    int i = 0;
    for (i = 0; i < 20; i++) {
        variable_test = i;
    }
    int jjk = funct_1();
    char arra[4] = "";
     _Bool b = 1;
    _Imaginary i1 = 1;

    _Complex c = 1;
    
    funct_2(7, 23);
    char y = funct_3('a', 'b');
    do {
        i++;
    } while (i < 100);
    float f = 57.8e-3;
    char str[20] = "assignment bisonflex\t";

    while (i < 20) {
        variable_test = i;
        i++;
    }

    funct5();
    main();
}