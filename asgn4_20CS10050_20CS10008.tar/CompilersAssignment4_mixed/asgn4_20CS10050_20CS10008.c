#include <stdio.h>
extern int yyparse();

void main(){
    yyparse() ;
    
}
