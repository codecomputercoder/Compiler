#include "myl.h"

#define BUFF 20
#define AFTERDECIMAL 6
#define INT_MAX __INT32_MAX__
#define INT_MIN (-INT_MAX - 1)

int printStr(char *s) {
    int length = 0;
    while (s[length] != '\0')
        length++;

    __asm__ __volatile__(
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        : "S"(s), "d"(length));

    return length;
}

int readInt(int *n) {
    char input[BUFF];
    int length;

    __asm__ __volatile__ (
        "movl $0, %%eax \n\t" 
        "movq $0, %%rdi \n\t"
        "syscall \n\t"
        : "=a"(length)
        :"S"(input), "d"(BUFF));

    if(length < 0)
        return ERR;
    
    int sign = 1, index = 0;
    long ret = 0;
    if(index < length) {
        if(input[index] == '-') {
            sign = -1;
            index++;
        } else if(input[index] == '+') {
            index++;
        }
    }
    
    while(index < length && input[index] != '\n') {
        if(input[index] < '0' || input[index] > '9')
            return ERR;
        int curr = (int)(input[index] - '0');
        ret *= 10;
        ret += (sign * curr);
        if(ret > INT_MAX || ret < INT_MIN)
            return ERR;
        index++;
    }

    *n = (int)ret;
    return OK;
}

int printInt(int n) {
    char buff[BUFF];
    int length = 0;
    if(n==0){
        buff[length++]='0';
    }
    else{
    if (n < 0) {
        buff[length++] = '-';
        n = -n;
    }
    while (n) {
        buff[length++] = (char)('0' + (n % 10));
        n /= 10;
    }
    if (length == 0)
        buff[length++] = '0';

    int starting = (buff[0] == '-' ? 1 : 0);
    int ending = length - 1;
    while (starting < ending) {
        char temp = buff[starting];
        buff[starting++] = buff[ending];
        buff[ending--] = temp;
    }
    }
    buff[length]='\n';

    __asm__ __volatile__(
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        : "S"(buff), "d"(length));
    return length;
}

int readFlt(float *f){
    char input[BUFF];
    int length;

    __asm__ __volatile__ (
        "movl $0, %%eax \n\t" 
        "movq $0, %%rdi \n\t"
        "syscall \n\t"
        : "=a"(length)
        :"S"(input), "d"(BUFF));

    if(length < 0)
        return ERR;
    
    int sign = 1, index = 0, multiplier = 0, msign = 1;
    float ret = 0;
    if(index < length) {
        if(input[index] == '-') {
            sign = -1;
            index++;
        } else if(input[index] == '+') {
            index++;
        }
    }
    
    while(index < length && input[index] != '\n' && input[index] != '.' && input[index] != 'E' && input[index] != 'e') {
        if(input[index] < '0' || input[index] > '9')
            return ERR;
        int curr = (int)(input[index] - '0');
        ret *= 10;
        ret += curr;
        index++;
    }

    if(index < length && input[index] == '.') {
        index++;
        float shift = 10.F;
        while(index < length && input[index] != '\n' && input[index] != 'E' && input[index] != 'e') {
            if(input[index] < '0' || input[index] > '9')
                return ERR;
            float curr = (float)(input[index] - '0');
            curr /= shift;
            ret += curr;
            shift *= 10;
            index++;
        }
    }

    if(index < length && (input[index] == 'E' || input[index] == 'e')) {
        index++;
        if(index < length) {
            if(input[index] == '-') {
                msign = -1;
                index++;
            } else if(input[index] == '+') {
                index++;
            }
        }
        while(index < length && input[index] != '\n') {
            if(input[index] < '0' || input[index] > '9')
                return ERR;
            int curr = (int)(input[index] - '0');
            multiplier *= 10;
            multiplier += curr;
            index++;
        }
    }


    for(int i = 0; i < multiplier; i++) {
        if(msign == 1) {
            ret *= 10;
        } else {
            ret /= 10;
        }
    }
    *f = sign * ret;
    return OK;
}

int printFlt(float f) {
    char buff[BUFF];
    int length = 0;
    if (f < 0) {
        buff[length++] = '-';
        f = -f;
    }

    int pureinteger = (int)f;
    f -= pureinteger;

    while (pureinteger) {
        buff[length++] = (char)('0' + (pureinteger % 10));
        pureinteger /= 10;
    }
    if (length == 0 || buff[length - 1] == '-')
        buff[length++] = '0';

    int starting = (buff[0] == '-' ? 1 : 0);
    int ending = length - 1;
    while (starting < ending) {
        char temp = buff[starting];
        buff[starting++] = buff[ending];
        buff[ending--] = temp;
    }

    buff[length++] = '.';

    for (int i = 0; i < AFTERDECIMAL; i++)
        f *= 10;

    int purefraction = (int)f;
    starting = length;

    for (int i = 0; i < AFTERDECIMAL; i++) {
        buff[length++] = (char)('0' + (purefraction % 10));
        purefraction /= 10;
    }

    ending = length - 1;
    while (starting < ending) {
        char temp = buff[starting];
        buff[starting++] = buff[ending];
        buff[ending--] = temp;
    }

    while(buff[length-1] == '0')
        length--;

    __asm__ __volatile__(
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        : "S"(buff), "d"(length));
    
    return length;
}