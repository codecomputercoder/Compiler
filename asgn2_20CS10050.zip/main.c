#include "myl.h"

#define INT_MAX __INT32_MAX__
#define INT_MIN (-INT_MAX - 1)

int main(){

    printStr("Using printStr \n");
    char *s[3] = {"First sample", "Second string.", ""};
    char *newline = "\n";
    for(int i=0; i<3; i++){ 
        int length = printStr(s[i]); 
        printStr("\ Length = ");
        printInt(length);
        printStr(newline);
    }
    printStr(newline);

    printStr("Using printInt \n");
    int integers[3] = {0, 11, -157};
    for(int i=0; i<3; i++){
        int length = printInt(integers[i]);
        printStr(" number of characters printed = ");
        printInt(length);
        printStr(newline);
    }
    printStr(newline);

    printStr("Using printFlt \n");
    float floatnumbers[5] = {0.F, -34.34F, 10.355F,0.4352F, -0.9984F};
    for(int i=0; i<5; i++){
        int length = printFlt(floatnumbers[i]);
        printStr(" number of characters printed = ");
        printInt(length);
        printStr(newline);
    }
    printStr(newline);

    printStr("Using readInt \n");
    int int_temp;
    int loop_cond = 0;
    do {
        printStr("Enter an integer: ");
        int ret = readInt(&int_temp);
        if(ret == ERR) 
            printStr("Invalid input. ");
        else{
            printStr("Entered integer: ");
            printInt(int_temp);
        }
        printStr("\nEnter 1  to read another integer , otherwise enter 0: ");
        readInt(&loop_cond);
    } while(loop_cond != 0);
    printStr(newline);

    printStr("Useing readFlt \n");
    float ftemp;
    loop_cond = 0;
    do {
        printStr("Enter a float: ");
        int ret = readFlt(&ftemp);
        if(ret == ERR) 
            printStr("Invalid input. ");
        else{
            printStr("Entered float is : ");
            printFlt(ftemp);
        }
        printStr("\nEnter 1  to read another float , otherwise enter 0:");
        readInt(&loop_cond);
    } while(loop_cond != 0);
    printStr(newline);
    
    printStr("Thank You!\n");

    return 0;
}
