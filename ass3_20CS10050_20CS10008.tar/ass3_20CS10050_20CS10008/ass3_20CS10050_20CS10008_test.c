#include <stdio.h>

/*
*   // Saikat Moi (20CS10050)
*   // Anirban Haldar (20CS10008)
*/

#define HELLO 1234

typedef struct test {
    int a;
    float b;
    char c;
    struct test *d;
};

int main() {
    

    //Testing CONSTANTS 
    double d1 = 234.;
    double d2 = 234.e2;
    double d3 = .00;
    const float f1 = .234;
    float f2 = .234E-2;
    float f3 = 0.234e+2;
    float f4 = 12.234e01;
    unsigned long l = 12902311123;
    signed short s = -12;
    int a = 7574;
    int b = 0;
    float c = 8.73;
    float d = -1e-2;
    float e = -73.88e8;
    char f = '\n';
    char g = 'k';

    //STRING LITERAL

    char *h = "Hello World\n";

    // Testing KEYWORD 
    auto, break, case, char, const, continue, default, do, double, else, enum, extern, float, for, goto, if, int, long, register, return, short, signed, sizeof, static, struct, switch, typedef, union, unsigned, void, volatile, while;
    restrict, return, short, signed, sizeof, static, struct, switch, typedef, union
 	unsigned, void, volatile, while, _Bool, _Complex, _Imaginary;

    
    int arr[10];
    int j=0;
   while(j<10){
    arr[j]=j+1;
    j++;
   }

    int sum = 0;
    for(int i = 0; i < 10; i++){
        sum += arr[i];
    }
    printf("%d\n", sum);

    test t;
    t.a = 1;
    t.b = 2.0;
    t.c = 'a';
    t.d = NULL;

    char s1[] = "A string // comments dont work here :P /* not even multiline ones */";

    enum months {jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec};
    enum months m = jan;
    printf("%d\n", m);

    _Imaginary asfa;
    _Bool b = 1;
    _Complex c = 1.0;

    return 0;   
}